/*
 * =====================================================================================
 *
 *       Filename:  NPDGCutSetterLinkDef.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  05/28/2013 03:54:22 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Hongwei Yang (UKY), yhw1630@gmail.com
 *   Organization:  
 *
 * =====================================================================================
 */
#pragma link C++ class NPDGRunFile;
#pragma link C++ class NPDGCutSetter;

